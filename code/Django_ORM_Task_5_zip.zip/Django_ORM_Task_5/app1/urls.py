from django.urls import path
from .views import student_list, edit_student

urlpatterns = [
    path("", student_list, name='student_list'),
    path("<int:student_id>/edit_student/", edit_student, name="edit_student")
]