from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Student
from django.core.paginator import Paginator
from django.db.models import Q
from .forms import StudentForm

# Create your views here.
def student_list(request):
    search_query = request.GET.get("q", "")

    students = Student.objects.all()

    if search_query:
        students = students.filter(
            Q(name__icontains=search_query) |
            Q(dept__icontains=search_query) |
            Q(city__icontains=search_query)

        )
    
    paginator = Paginator(students, 10)
    page_num = request.GET.get("page")
    page_obj = paginator.get_page(page_num)

    return render(request, "app1/students.html", {
        "page_obj": page_obj,
        "search_query": search_query
    })


def edit_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)

    # Check if ID is even
    if student.id % 2 != 0:
        messages.error(request, "You can only edit students with even ID!")
        return redirect('student_list')  # redirect back

    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student updated successfully!")
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)

    return render(request, "app1/edit_student.html", {"form": form, "student": student})